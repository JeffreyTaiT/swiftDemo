import UIKit

var str = "Hello, playground"

//定义常量
let aaa = 666
var bbb = 888,ccc = 999

//类型标注
var welcome:String = "welcome"
var num:Int = 6
var douNum:Double = 7.22

//输出
print(welcome)
print("num的值是\(num)")

//整形d浮点转换
let two = 2
let pointOneFourOneFiveNine = 0.14159
let pi = Double(two) + pointOneFourOneFiveNine
print(pi)
let integerPi = Int(pi)
print(integerPi)

//元组
//任何类型的排列都可以被用来创建一个元组，他可以包含任意多的类型。例如 (Int, Int, Int) 或者 (String, Bool) ，实际上，任何类型的组合都是可以的
let http404Error = (404, "Not Found")
print(http404Error)
let (statusCode, statusMessage) = http404Error
print("The status code is \(statusCode)")
// prints "The status code is 404"
print("The status message is \(statusMessage)")
// prints "The status message is Not Found"

let possibleString: String? = "An optional string."
let forcedString: String = possibleString!
print(forcedString)

//错误处理
//当一个函数遇到错误情况，他会抛出一个错误，这个函数的访问者会捕捉到这个错误，并作出合适的反应。
func canThrowAnError() throws {
    // this function may or may not throw an error
}

do {
    try canThrowAnError()
    // no error was thrown
} catch {
    // an error was thrown
}

//断言进行调试
//let age = -3
//assert(age >= 0, "A person's age cannot be less than zero")


///赋值运算
let three = 3
let minusThree = -three // minusThree equals -3
let plusThree = -minusThree // plusThree equals 3, or "minus minus three"
let result = plusThree + 1
print(result)

var a = 1
a += 2

//  a ?? b  -->  a != nil ? a! : b

//区间运算符
for index in 1...5 {
    print("\(index) times 5 is \(index * 5)")
}

//半开区间运算符
let names = ["Anna", "Alex", "Brian", "Jack"]
let count = names.count
for i in 0..<count {
    print("Person \(i + 1) is called \(names[i])")
}

//单侧区间
for name in names[2...] {
    print(name)
}

for name in names[..<2] {
    print(name)
}
