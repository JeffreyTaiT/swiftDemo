import UIKit

var str = "Hello, playground"

//多行字符串字面量是用三个双引号引起来
let quotation = """
The White Rabbit put on his spectacles.  "Where shall I begin,
please your Majesty?" he asked.

"Begin at the beginning," the King said gravely, "and go on
till you come to the end; then stop."
"""
print(quotation)

if !quotation.isEmpty {
    print("Something to see here")
}

var variableString = "Horse"
variableString += " and carriage"
print(variableString)

//String类型是一种值类型

//遍历字符
for character in "Dog!?" {
    print(character)
}

let catCharacters: [Character] = ["C", "a", "t", "!", "?"]
let catString = String(catCharacters)
print(catString)

//字符串拼接
let string1 = "hello"
let string2 = " there"
var welcome = string1 + string2
print(welcome)

var instruction = "look over"
instruction += string2

let exclamationMark: Character = "!"
instruction.append(exclamationMark)
print(instruction)

let multiplier = 3
let message = "\(multiplier) times 2.5 is \(Double(multiplier) * 2.5)"

let precomposed: Character = "\u{D55C}"
print(precomposed)


//字符统计
let unusualMenagerie = "Koala ?, Snail ?, Penguin ?, Dromedary ?"
print("unusualMenagerie has \(unusualMenagerie.count) characters")

//字符串索引
let greeting = "Guten Tag!"
greeting[greeting.startIndex]
// G
greeting[greeting.index(before: greeting.endIndex)]
// !
greeting[greeting.index(after: greeting.startIndex)]
// u
let index = greeting.index(greeting.startIndex, offsetBy: 7)
greeting[index]

//插入和删除
var originalString = "hollow"
originalString.insert("!", at: originalString.endIndex)
originalString.insert(contentsOf: "you", at: originalString.endIndex)

originalString.remove(at: originalString.index(before: originalString.endIndex))


//字符串比较
let quotationString = "We're a lot alike, you and I."
let sameQuotation = "We're a lot alike, you and I."
if quotationString == sameQuotation {
    print("These two strings are considered equal")
}

if quotationString.hasPrefix("We") {
    print("1111")
}
if sameQuotation.hasSuffix("I."){
    print("2222")
}


//字符串的 Unicode 表示法
//UTF-8 表示法
let dogString = "Dog‼?"
for codeUnit in dogString.utf8 {
    print("\(codeUnit) ", terminator: "")
}


//UTF-16 表示法
for codeUnit in dogString.utf16 {
    print("\(codeUnit) ", terminator: "")
}

//Unicode 标量表示法
for scalar in dogString.unicodeScalars {
    print("\(scalar.value) ", terminator: "")
}
